from support import logger
"""
from support import d, get_logger, logger
from .discord import SupportDiscord
from .ffmpeg import SupportFfmpeg
from .file import SupportFile
from .image import SupportImage
from .process import SupportProcess
from .string import SupportString
from .util import SupportUtil, pt, default_headers, SingletonClass, AlchemyEncoder
from .aes import SupportAES
from .yaml import SupportYaml
"""
